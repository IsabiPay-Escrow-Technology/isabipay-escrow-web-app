<?php

namespace CoinGate\APIError;

// HTTP Status 404
class RecordNotFound extends NotFound
{
}

