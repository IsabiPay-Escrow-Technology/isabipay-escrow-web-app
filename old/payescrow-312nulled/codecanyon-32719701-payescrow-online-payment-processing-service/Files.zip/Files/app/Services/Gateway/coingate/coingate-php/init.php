<?php

// CoinGate Class
require(dirname(__FILE__) . '/lib/CoinGate.php');

// Exception Class
require(dirname(__FILE__) . '/lib/APIError/APIError.php');

// Exception Class
require(dirname(__FILE__) . '/lib/Exception.php');

// Merchant Class
require(dirname(__FILE__) . '/lib/Merchant.php');

// Order Class
require(dirname(__FILE__) . '/lib/Merchant/Order.php');
